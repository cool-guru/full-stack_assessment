import { Component, OnInit, ViewChild } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-courses-list',
  templateUrl: './courses-list.component.html',
  styleUrls: ['./courses-list.component.scss']
})
export class CoursesListComponent implements OnInit {

  searchQuery = '';

  constructor(private courseService: CourseService) {}
  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses(): void {
    this.courseService.getCourses(this.searchQuery, 0, 10).subscribe(data => {
      console.log('data', data);
    });
  }
}
