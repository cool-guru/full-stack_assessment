import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  private apiUrl = 'http://localhost:8000';

  constructor(private http: HttpClient) {}

  getCourses(search: string, skip: number, limit: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/courses`, { params: { search, skip, limit } });
  }

  createCourse(course: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/courses`, course);
  }

  updateCourse(courseId: string, course: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/courses/${courseId}`, course);
  }

  deleteCourse(courseId: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/courses/${courseId}`);
  }
}
